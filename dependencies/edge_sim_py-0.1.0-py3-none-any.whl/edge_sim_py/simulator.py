""" Contains all the simulation management functionality (dataset loading, metrics collection, etc.).
"""
# Simulator Components
from edge_sim_py.object_collection import ObjectCollection
from edge_sim_py.components.base_station import BaseStation
from edge_sim_py.components.edge_server import EdgeServer
from edge_sim_py.components.topology import Topology
from edge_sim_py.components.user import User
from edge_sim_py.components.application import Application
from edge_sim_py.components.service import Service

# Python Libraries
import json
import typing
import time
import random


class Simulator(ObjectCollection):
    """Class responsible for managing the simulation."""

    # Class attribute that allows this class to use helper methods from ObjectCollection
    instances = []

    def __init__(self):
        """Creates a Simulator object."""
        self.id = Simulator.count() + 1

        self.topology = None
        self.seed = 1
        self.simulation_steps = 0
        self.current_step = 0
        self.metrics = {}
        self.original_system_state = {}

        # Defining a seed value to enable experiments' reproducibility
        random.seed(self.seed)

        # Adding the new object to the list of instances of its class
        Simulator.instances.append(self)

    def load_dataset(self, input_file: str):
        """Spawns a simulation environment based on a dataset file.

        Args:
            input_file (str): Dataset file name.
        """
        with open(input_file, "r") as read_file:
            data = json.load(read_file)

        # Loading simulation specs
        self.simulation_steps = data["simulation_steps"]

        # Creating base stations
        if "base_stations" in data:
            for obj_data in data["base_stations"]:
                BaseStation(
                    obj_id=obj_data["id"],
                    coordinates=obj_data["coordinates"],
                    wireless_delay=obj_data["wireless_delay"],
                )

        # Creating edge servers
        if "edge_servers" in data:
            for obj_data in data["edge_servers"]:
                edge_server = EdgeServer(
                    obj_id=obj_data["id"],
                    coordinates=obj_data["coordinates"],
                    capacity=obj_data["capacity"],
                )
                if "base_station" in obj_data:
                    base_station = BaseStation.find_by_id(obj_data["base_station"])
                    edge_server.base_station = base_station
                    base_station.edge_servers.append(edge_server)

        # Creating network topology
        if "network" in data:
            topology = Topology()

            # Storing topology as an attribute of the Simulator instance
            self.topology = topology

            # Creating links
            if "links" in data["network"]:
                for obj_data in data["network"]["links"]:

                    # Finding objects that are connected by the link
                    try:
                        node1_type = obj_data["nodes"][0]["type"]
                        node2_type = obj_data["nodes"][1]["type"]
                        node1 = globals()[node1_type].find_by_id(obj_data["nodes"][0]["id"])
                        node2 = globals()[node2_type].find_by_id(obj_data["nodes"][1]["id"])
                    except TypeError:
                        print(f"Unknown node types ('{node1_type}, {node2_type}') referenced in Link_{obj_data['id']}")

                    # Adding link to the NetworkX topology
                    topology.add_edge(node1, node2)

                    # Adding link parameters
                    topology[node1][node2]["id"] = obj_data["id"]
                    topology[node1][node2]["delay"] = obj_data["delay"]
                    topology[node1][node2]["bandwidth"] = obj_data["bandwidth"]
                    topology[node1][node2]["demand"] = 0

        # Creating applications
        if "applications" in data:
            for obj_data in data["applications"]:
                Application(obj_id=obj_data["id"], network_demand=obj_data["network_demand"])

        # Creating services
        if "services" in data:
            for obj_data in data["services"]:
                service = Service(obj_id=obj_data["id"], demand=obj_data["demand"])

                # Linking services and their applications
                if "application" in obj_data:
                    # Finding the service application by its ID
                    application = Application.find_by_id(obj_id=obj_data["application"])

                    # Connecting the service and its application
                    application.services.append(service)
                    service.application = application

                # Connecting services and edge servers
                if "server" in obj_data:
                    server = obj_data["server"]
                    # Finding the service host by its ID
                    server = globals()[server["type"]].find_by_id(server["id"])

                    # Hosting the service inside the edge server
                    server.services.append(service)
                    server.demand += service.demand
                    service.server = server

        # Creating users
        if "users" in data:
            for obj_data in data["users"]:
                user = User(
                    obj_id=obj_data["id"],
                    coordinates_trace=obj_data["coordinates_trace"],
                )
                # Defining user's initial location
                user.coordinates = user.coordinates_trace[0]

                # Connecting users and base stations
                if "base_station" in obj_data:
                    base_station = obj_data["base_station"]
                    # Finding the client base station by its ID
                    base_station = globals()[base_station["type"]].find_by_id(base_station["id"])

                    # Connecting the client to its base station
                    user.base_station = base_station
                    base_station.users.append(user)

                # Connecting users and applications
                applications = obj_data["applications"]
                for app_data in applications:
                    # Finding the application by its ID
                    application = Application.find_by_id(obj_id=app_data["id"])

                    # Connecting the client to the applications it consumes
                    application.users.append(user)
                    user.applications.append(application)

                    # Gathering the set of links used to communicate the client and the application
                    communication_path = []
                    for link_node_data in app_data["communication_path"]:
                        # Finding objects that form the link
                        try:
                            node_type = link_node_data["type"]
                            node = globals()[node_type].find_by_id(link_node_data["id"])
                        except TypeError:
                            print(f"Unknown node type ('{node1_type}') referenced in the communication path of {user}")
                        communication_path.append(node)

                    # Storing application's metadata inside user's attributes
                    user.communication_paths[application] = communication_path
                    user.delay_slas[application] = app_data["delay_sla"]
                    user.delays[application] = 0

                    # Updating the demand of each link used to communicate the client with his application
                    if len(communication_path) > 1:
                        for i in range(len(communication_path) - 1):
                            # Finding the nodes connected by the link
                            node1 = communication_path[i]
                            node2 = communication_path[i + 1]

                            # Updating link load according to the application's network demand
                            link = topology[node1][node2]
                            link["demand"] += application.network_demand

    def set_simulator_attribute_inside_objects(self):
        """Adds a reference to the Simulator instance inside each created object"""
        objects = Topology.all() + BaseStation.all() + EdgeServer.all() + Application.all() + Service.all() + User.all()
        for obj in objects:
            obj.simulator = self

    def run(self, algorithm: typing.Callable):
        """Executes the simulation.

        Args:
            algorithm (typing.Callable): Algorithm that will be executed during simulation.
        """
        self.set_simulator_attribute_inside_objects()

        # Adding a reference to the network topology inside the Simulator instance
        self.topology = Topology.first()

        # Creating an empty list to accommodate the simulation metrics
        algorithm_name = f"{str(algorithm).split(' ')[1]}-{time.time()}"
        self.metrics[algorithm_name] = []

        # Storing original objects state
        self.store_original_state()

        # Iterating over simulation time steps
        for simulation_step in range(1, self.simulation_steps + 1):
            # Updating system state according to the new simulation time step
            self.update_state(step=simulation_step)

            # Collecting metrics for the current simulation step
            self.collect_metrics(algorithm=algorithm_name)

            # Executing user-specified algorithm
            algorithm()

        # Collecting metrics after the algorithm execution in the last simulation time step
        self.collect_metrics(algorithm=algorithm_name)

        # Restoring original objects state
        self.restore_original_state()

    def store_original_state(self):
        """Stores the original state of all objects in the simulator."""
        # Services placement
        self.original_system_state["services"] = {}
        for service in Service.all():
            self.original_system_state["services"][service] = {"server": service.server}

        # Users locations and applications routing
        self.original_system_state["users"] = {}
        for user in User.all():
            self.original_system_state["users"][user] = {
                "base_station": user.base_station,
                "communication_paths": user.communication_paths.copy(),
            }

    def restore_original_state(self):
        """Restores the original state of all objects in the simulator."""
        # Services placement
        for service in Service.all():
            server = self.original_system_state["services"][service]["server"]
            if server is not None:
                service.migrate(target_server=server)
            service.migrations = []

        # Users locations and applications routing
        for user in User.all():
            user.coordinates = user.coordinates_trace[0]
            user.base_station = self.original_system_state["users"][user]["base_station"]
            for application in user.applications:
                user.set_communication_path(
                    app=application,
                    communication_path=self.original_system_state["users"][user]["communication_paths"][application],
                )

    def update_state(self, step: int):
        """Updates the system state.

        Args:
            step (int): Current simulation time step.
        """
        self.current_step = step

        # Updating users' mobility
        for user in User.all():
            # Updating user's location
            user.coordinates = user.coordinates_trace[step - 1]

            # Connecting the user to the closest base station
            user.base_station = user.get_closest_base_stations()[0]

            for application in user.applications:
                # Recomputing user communication paths
                user.set_communication_path(app=application)
                # Updating user-perceived delay when accessing applications
                user.compute_delay(app=application, metric="latency")

    def collect_metrics(self, algorithm: str):
        """Collects simulation metrics.

        Args:
            algorithm (str): Name of the algorithm being executed.
        """
        sla_violations = 0
        migrations = 0

        # Computing user-related metrics (SLA violations)
        for user in User.all():
            for app in user.applications:
                if user.delays[app] > user.delay_slas[app]:
                    sla_violations += 1

        # Computing services-related metrics (Number of migrations)
        for service in Service.all():
            # As the metrics collection method is called before the algorithm execution, we compute the number of
            # migrations performed in the previous step, except for those migrations performed after the algorithm
            # execution in the last simulation time step.
            for migration in service.migrations:
                if (
                    migration["step"] == self.current_step - 1
                    or self.current_step == self.simulation_steps
                    and migration["step"] == self.current_step
                ):
                    migrations += 1

        # Creating the structure to accommodate simulation metrics
        self.metrics[algorithm].append(
            {
                "step": self.current_step,
                "sla_violations": sla_violations,
                "migrations": migrations,
            }
        )

    def show_results(self):
        """Displays the simulation results."""
        for algorithm, results in self.metrics.items():

            sla_violations = 0
            migrations = 0

            for step_results in results:
                sla_violations += step_results["sla_violations"]
                migrations += step_results["migrations"]

            print(f"Algorithm: {algorithm}")
            print(f"    SLA violations: {sla_violations}")
            print(f"    Migrations: {migrations}")
