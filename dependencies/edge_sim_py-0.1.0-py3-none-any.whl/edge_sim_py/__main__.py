# pylint: disable=invalid-name
"""Contains the basic structure necessary to execute the simulator.
"""
from edge_sim_py.simulator import Simulator
from edge_sim_py.heuristics.follow_vehicle import follow_vehicle
from edge_sim_py.heuristics.never_migrate import never_migrate


def main():
    simulator = Simulator()

    simulator.load_dataset(input_file="datasets/example1.json")

    simulator.run(algorithm=never_migrate)
    simulator.run(algorithm=follow_vehicle)

    simulator.show_results()


if __name__ == "__main__":
    main()
