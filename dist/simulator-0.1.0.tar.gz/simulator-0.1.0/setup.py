# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['simulator', 'simulator.algorithms', 'simulator.components_extensions']

package_data = \
{'': ['*']}

install_requires = \
['edge-sim-py @ dependencies/edge_sim_py-0.1.0-py3-none-any.whl',
 'pymoo>=0.5.0,<0.6.0']

setup_kwargs = {
    'name': 'simulator',
    'version': '0.1.0',
    'description': 'Location-Aware Maintenance Strategies for Edge Infrastructures',
    'long_description': None,
    'author': 'Paulo Severo',
    'author_email': 'opaulosevero@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7.1,<3.10',
}


setup(**setup_kwargs)
